# This directory includes all RELEASE- depended APT-Packages to be installed!

[drwxr-xr-x]  .
├── [drwxr-xr-x]  debian
│   ├── [-rw-r--r--]  bookworm.txt
│   ├── [-rw-r--r--]  bullseye.txt
│   ├── [-rw-r--r--]  buster.txt
│   ├── [-rw-r--r--]  sid.txt
│   ├── [-rw-r--r--]  stretch.txt
│   └── [-rw-r--r--]  trixie.txt
├── [-rw-r--r--]  default.txt
├── [-rw-r--r--]  README.md
└── [drwxr-xr-x]  ubuntu
    ├── [-rw-r--r--]  bionic.txt
    ├── [-rw-r--r--]  focal.txt
    ├── [-rw-r--r--]  jammy.txt
    ├── [-rw-r--r--]  noble.txt
    └── [-rw-r--r--]  xenial.txt

3 directories, 13 files